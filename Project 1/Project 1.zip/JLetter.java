/**
*This program is to print the letter "J".
*with the word "JAVA"
*
*Project 1
*@author Matthew Bankson
*@version January 16, 2019
*/
public class JLetter {
/**
*Prints a large "J".
*@param args Command line arguments - not used.
*/
   public static void main(String[] args) {
      System.out.println("JAVAJAVAJAVA");
      System.out.println("JAVAJAVAJAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("J     JAVA");
      System.out.println("JA    JAVA");
      System.out.println(" JAVAJAVA");
      System.out.println("  JAVAJA");
   }
}