/**
*This program is to print my short-term,
*medium-term, and long-term goals.
*
*Project 1
*@author Matthew Bankson
*@version January 16, 2019
*/
public class MyLifeGoals {
/**
*Prints my life goals.
*@param args Command line arguments - not used.
*/
   public static void main(String[] args) {
   /**
   *Prints my name and short-term goals.
   */
      System.out.println("Matthew Bankson\n");
      System.out.println("My short-term goal is to get an \"A\" "
         + "in Physics II this semester. It would be great to strengthen "
         + "my existing friendships and make more friends along the way");
         /**
         *Prints my medium-term goals.
         */
      System.out.println("My medium-term goal is to graduate "
         + "and get a job. I would like to be able to live "
         + "in the Southeast and travel across the country.");
         /**
         *Prints my long-term goals.
         */
      System.out.println("My long-term goal is to have a family "
         + "and make enough  money to retire comfortably. I also "
         + "want to be able to give money to help the poor.");
   }
}